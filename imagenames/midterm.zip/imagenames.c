//
// Created by Piermarco Barbè on 2019-04-03.
//

#include <strings.h>
#include <stdio.h>
#include <stdlib.h>

#include "../arrayListString.h"
#include "../stringsUtils.h"
#include "../readFile.h"




char * getFileNameFromComplete(char * s, char * ext){

//    printf("getFileNameFromComplete: %s\n", s);

    char * last = s;

    char * pch;
//    printf ("Splitting string \"%s\" into tokens:\n",s);
    pch = strtok (s, "/");

//    printf("%s", pch);

    while (pch != NULL)
    {
//        printf ("%s\n",pch);
        last = pch;
        pch = strtok (NULL, "/");
    }

    // last is complete filename


//    last = replaceString(last, ext, "");

    int need = strlen(last) - strlen(ext);

//    printf("need:%d\n", need);
    char * ret = malloc(need);

    strncpy(ret, last, need);

    ret[need]  = 0;
//    printf("ret: %s\n", ret);

    last = ret;

//    printf("returning '%s'\n", last);


    return last;

}

char * formatString(char * s, struct arrayListString * extensions){

    struct arrayListString * root = extensions;

    char * extension;

    while(root){
        extension = getSubstringIntInt(s, strlen(s) - strlen(root->value)+1, strlen(s));
//        printf("ext: %s\n", extension);
        if(strcmp(extension, root->value) == 0){
//            printf("Match on %s \n", extension);
//            printf("'%s'\n", getFileNameFromComplete(s, extension));
            return getFileNameFromComplete(s, extension);
        }
        root = root->next;
    }

    return 0;

//    return last;

}

int main(int argc, char * argv[]){


    struct arrayListString * extensions = newArrayListStringItemVoid();
    struct arrayListString * head_extensions = extensions;

    if(argc == 2){

        struct arrayListString * inputFile = readFile(argv[1]);

        int k = 0;

        while (inputFile){

            if(k == 0){
                arrayListStringItemSet(extensions, 0, replaceString(inputFile->value, "\n", ""));
            } else {
                arrayListStringItemPush(replaceString(inputFile->value, "\n", ""), extensions);
            }

            k++;
            inputFile = inputFile->next;

        }


    } else {

        arrayListStringItemSet(extensions, 0, ".jpg");

        arrayListStringItemPush(".jpeg", extensions);
        arrayListStringItemPush(".png", extensions);
        arrayListStringItemPush(".tiff", extensions);
        arrayListStringItemPush(".tif", extensions);
    }







//    root_inputFile = inputFile;




//    printArrayListString(extensions);

    struct arrayListString * input = newArrayListStringItemVoid();

    char str[1000];

    int c = 0;



    while(fgets(str, sizeof(str), stdin)){


        strcpy(str, removeChar(str, '\n'));

//        printf("str: %s\n", str);

        if(c == 0){
            arrayListStringItemSet(input, 0, str);
        } else {
            arrayListStringItemPush(str, input);
        }
        c++;
        continue;
    }
//
//
//    printArrayListString(input);

//    printf("%d\n", arrayListStringSize(input));
    if(arrayListStringSize(input) == 1){
        return 0;
    }
//
    char * s;

    while (input){
        s = formatString(input->value, extensions);

        if(s){
            printf("%s\n", s);
        }
        input = input->next;
    }
//
    return 0;
}