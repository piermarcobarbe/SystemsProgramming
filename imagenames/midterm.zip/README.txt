Since i am using libraries written by myself, compiling the midterm can be done with:
cc imagenames.c arrayListString.c stringsUtils.c readFile.c -o imagenames

From here, imagenames can be tested.
